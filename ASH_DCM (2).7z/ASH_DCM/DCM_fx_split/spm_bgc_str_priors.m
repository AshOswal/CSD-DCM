function [pE,pC] = spm_bgc_str_priors()
% prior moments for a basal ganglia circuit
% only contains priors for intrinsic parameters
% priors for extrinsic parameters are defined in spm_cmc_priors


% synaptic parameters
%--------------------------------------------------------------------------

% E.T  = sparse(1,1);   V.T  = [1/4];
E.T  = -1.13;   V.T  = [1/4];

% E.G=[ 0 ]; V.G=[ 1/2 ]; 
E.G=[ -0.77 ]; V.G=[ 1/2 ];

% E.S  = 0;             V.S  = 1/4;                % slope of sigmoid  
E.S  = -1;             V.S  = 1/4;                % slope of sigmoid  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pE     = E;
pC     = V;