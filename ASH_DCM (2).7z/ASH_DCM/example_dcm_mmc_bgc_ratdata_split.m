clear all, close all
% prepareratdataDCM_split()
% example script of an inversion of a MMC-BGC combined DCM
% 2 data channels: 1 beamformed MEG source, 1 LFP channel from STN
% 2 conditions: OFF and ON medication
% condition-related modulations allowed in all synaptic connections
% taking posteriors from grand average inversion as mean prior values for G, T, and A

DCM=[];
DCM.name        = 'example_inversion';
% DCM.xY.Dfile    = ['mergedrat_lesion_group.mat'];
DCM.xY.Dfile    = ['mergedrat_split_lesion.mat'];


cfg.channel = {'fEEG','STN 20','GP 1','STR 13'};

% DCM.xY.Dfile    = ['rescaled_OFFON_DF_left.mat']
DCM.Sname       = {'cortex';'stn';'gp';'str'};

DCM.options.model(1).source = 'MMC';    % specify name of the first model (in same order as data)
DCM.options.model(1).B      = 1:14;     % all intrinsic synaptic modulations can be modulated between conditions

DCM.options.model(2).source = 'STN';    % specify name of the first model (in same order as data)
DCM.options.model(2).J      = 1;        % specify state that contributes to observed data: 1=Striatum, 3=GPe; 5=STN; 7=GPi; 9=Thalamus
% DCM.options.model(2).B      = [1];    % all intrinsic synaptic modulations can be modulated between conditions

DCM.options.model(3).source = 'GPE';    
DCM.options.model(3).J      = 1;
DCM.options.model(3).B      = [1];   

DCM.options.model(4).source = 'STR';    
DCM.options.model(4).J      = 1;       
DCM.options.model(4).B      = [1];   


DCM.xY.modality = 'LFP';
DCM.xY.Ic       = 1:4;

DCM.options.Fdcm    = [8 48];
DCM.options.trials  = [1];
DCM.options.Tdcm    = [1 3000];
DCM.options.D       =  1;
DCM.options.spatial = 'LFP';

%modulation of individual extrinsic connections - only works if corresponding DCM.Bs are set
% DCM.options.model(1).Zf{1,1} = zeros(6,6);       %single forward modulation
% DCM.options.model(1).Zb{1,1} = zeros(6,6);       %single forward modulation
% DCM.options.model(1).Zb{1,1} = [0 0 0 0;1 0 0 0; 0 0 0 0; 0 1 1 0];       %split backward modulation: (in)direct connection
% DCM.options.model(1).Zb{2,1} = [0 0 0 0;1 0 0 0; 0 0 0 0; 0 1 1 0];       %split backward modulation: hyperdirect connection

%DCM.Sname       = {'cortex';'stn';'gpe';'str';'gpi';'thal'};
% G(1,1) = str -> str (-ve self)
% G(1,2) = str -> gpe (-ve ext)
% G(1,3) = gpe -> gpe (-ve self)
% G(1,4) = gpe -> stn (-ve ext)
% G(1,5) = stn -> gpe (+ve ext)
% G(1,6) = str -> gpi (-ve ext)
% G(1,7) = stn -> gpi (+ve ext)
% G(1,8) = gpi -> gpi (-ve self)
% G(1,9) = gpi -> tha (-ve ext)

% Forward (/Excitatory for subcortical sources)
DCM.A{1}        = zeros(4,4);
DCM.A{1}(2,1)   = 1;                % cortex -> STN modeled as forward connection
DCM.A{1}(4,1)   = 1;                % cortex -> STR modeled as forward connection

DCM.A{1}(3,2)   = 1;                % STN -> GPe modeled as forward connection
% DCM.A{1}(5,2)   = 1;                % STN -> GPi modeled as forward connection
% 
% DCM.A{1}(1,6)   = 1;                % Thal -> cortex modeled as forward connection
%                                     % Should be backward but as excitatory
%                                     % we model as forward
% Backward (/Inhibitory for subcortical sources)
DCM.A{2}        = zeros(4,4);
DCM.A{2}(2,3)   = 1;                % GPe -| STN modeled as forward connection

DCM.A{2}(3,4)   = 1;                % STR -| GPe modeled as forward connection

% DCM.A{2}(5,4)   = 1;                % STR -| GPi modeled as forward connection
% 
% DCM.A{2}(5,4)   = 1;                % GPi -| Thal modeled as forward connection
% 
% Modulation
DCM.B{1}        = zeros(4,4);
DCM.B{1}(3,2)   = 1;                % STN -> GPe modeled as forward connection
DCM.B{2}        = zeros(4,4);
DCM.B{2}(2,3)   = 1;                % GPe -| STN modeled as forward connection

% If matrix Zf/Zb dont match DCM.B then former are ignored.

DCM.xU.X        = [0];           %(0=OFF, 1=ON)
DCM.xU.name     = {'OFF'};

DCM.M.nodelay   = 2;        % 1) asymetric no delays; 2) remove all delays for self connections
                            %eliminates delay self-connections


%%%%%%%%%

% % take priors means from posteriors of inversion grand average
% load('priors_grandaverage_OFF.mat');
% 
% DCM.M.MMC_T     = MMC_T;
% DCM.M.MMC_G     = MMC_G;
% DCM.M.BGC_T     = BGC_T;
% DCM.M.BGC_G     = BGC_G;
% DCM.M.BGC_E     = BGC_E;
% DCM.M.MMC_E     = MMC_E;


%%%%%%%%%%

DCM = spm_dcm_csd(DCM);

%%%%%%%%%

% use multiple runs to get out of early convergence / local minima
cnt=1;

while cnt<=3;
    
    DCM.M.P=DCM.Ep;
    DCM = spm_dcm_csd(DCM);
    
    cnt=cnt+1;
%     disp([fnames{fn},'  rep ',num2str(cnt)]);
end
save('onerat_bgm_DCM_multipass_split')
% save('rat_bgm_DCM_multipass')